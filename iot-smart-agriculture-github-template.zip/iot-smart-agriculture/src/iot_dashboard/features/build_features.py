from __future__ import annotations

import pandas as pd


def make_lag_features(
    df: pd.DataFrame,
    lags: list[int] = [1, 2, 3, 6],
    freq_minutes: int = 60,
) -> pd.DataFrame:
    """Create lag features per zone. Assumes regular cadence after resampling.
    freq_minutes: expected sampling interval (default: 60min).
    """
    df = df.copy()
    df = df.sort_values(["zone", "timestamp"])

    numeric = ["soil_moisture_pct", "temperature_c", "humidity_pct", "wind_kmh", "light_lux"]

    # Resample each zone to uniform cadence
    out = []
    for zone, g in df.groupby("zone"):
        g = g.set_index("timestamp").sort_index()
        g = g.resample(f"{freq_minutes}min").mean().interpolate(limit=2)
        g["zone"] = zone
        g = g.reset_index()
        for col in numeric:
            for k in lags:
                g[f"{col}_lag{k}"] = g[col].shift(k)
        out.append(g)

    feat = pd.concat(out, ignore_index=True).dropna()
    return feat


def make_targets(feat: pd.DataFrame, horizon_steps: int = 6) -> pd.DataFrame:
    """Create supervised targets by shifting forward within each zone.
    horizon_steps: number of rows ahead (e.g., 6 hours ahead if 1h cadence).
    """
    feat = feat.copy()
    feat = feat.sort_values(["zone", "timestamp"])

    feat["soil_moisture_target"] = feat.groupby("zone")["soil_moisture_pct"].shift(-horizon_steps)
    feat["temperature_target"] = feat.groupby("zone")["temperature_c"].shift(-horizon_steps)

    return feat.dropna()
