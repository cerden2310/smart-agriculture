from __future__ import annotations

import pandas as pd


def basic_clean(df: pd.DataFrame) -> pd.DataFrame:
    """Basic cleaning:
    - sort by timestamp
    - drop duplicate timestamps per zone
    - clip ranges to sensible bounds
    - forward-fill small gaps per zone
    """
    df = df.copy()
    df = df.sort_values(["zone", "timestamp"])
    df = df.drop_duplicates(subset=["zone", "timestamp"], keep="last")

    # Clip to sensible physical bounds
    df["soil_moisture_pct"] = df["soil_moisture_pct"].clip(0, 100)
    df["humidity_pct"] = df["humidity_pct"].clip(0, 100)
    df["temperature_c"] = df["temperature_c"].clip(-30, 60)
    df["wind_kmh"] = df["wind_kmh"].clip(0, 200)
    df["light_lux"] = df["light_lux"].clip(0, 200000)

    # Simple missing handling
    numeric_cols = ["soil_moisture_pct", "temperature_c", "humidity_pct", "wind_kmh", "light_lux"]
    df[numeric_cols] = df.groupby("zone")[numeric_cols].ffill().bfill()

    return df
