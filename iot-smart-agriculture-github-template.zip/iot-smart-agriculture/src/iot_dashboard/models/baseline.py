from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Tuple

import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error
from sklearn.model_selection import TimeSeriesSplit


@dataclass
class BaselineResult:
    model: Ridge
    mae: float


def train_ridge_baseline(
    df: pd.DataFrame,
    target_col: str,
    feature_cols: list[str],
    alpha: float = 1.0,
    n_splits: int = 5,
) -> BaselineResult:
    """Simple baseline: Ridge regression with time-series CV."""
    X = df[feature_cols].to_numpy()
    y = df[target_col].to_numpy()

    tscv = TimeSeriesSplit(n_splits=n_splits)
    maes = []

    model = Ridge(alpha=alpha, random_state=0)

    for train_idx, test_idx in tscv.split(X):
        model.fit(X[train_idx], y[train_idx])
        pred = model.predict(X[test_idx])
        maes.append(mean_absolute_error(y[test_idx], pred))

    # Fit on all data at the end
    model.fit(X, y)
    return BaselineResult(model=model, mae=float(np.mean(maes)))
