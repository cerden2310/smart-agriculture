from __future__ import annotations

from pathlib import Path
import pandas as pd


def read_sensor_csv(path: Path) -> pd.DataFrame:
    """Read raw sensor CSV with expected columns.
    Required:
      - timestamp (ISO string)
      - zone (str)
      - soil_moisture_pct (float)
      - temperature_c (float)
      - humidity_pct (float)
      - wind_kmh (float)
      - light_lux (float)
    """
    df = pd.read_csv(path)
    if "timestamp" not in df.columns:
        raise ValueError("Missing 'timestamp' column")
    df["timestamp"] = pd.to_datetime(df["timestamp"], utc=True).dt.tz_convert(None)
    return df
