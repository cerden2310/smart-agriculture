# Akıllı Tarım İzleme Sistemi (IoT + Applied Data Science)

Bu repo; veri üretimi/ingestion → temizlik → feature engineering → baseline model → (statik) dashboard yayınlama → AWS EC2 deploy akışını uçtan uca göstermek için hazırlanmıştır.

> Dashboard arayüzü **birebir aynen korunmuştur** ve `dashboards/static/index.html` altında bulunur.

## Repo Yapısı
- `data/`  
  - `raw/`: ham veri (commit etmeyin)  
  - `processed/`: işlenmiş veri (commit etmeyin)
- `notebooks/`: EDA & deneyler (örnek notebook + yönergeler)
- `src/`: yeniden kullanılabilir modüller (io, cleaning, features, models)
- `dashboards/`: dashboard + servis uygulaması
- `models/`: kaydedilen model artefaktları
- `docs/`: rapor, öneri/proposal, figürler

## Hızlı Başlangıç (Local)
### 1) Kurulum
```bash
python -m venv .venv
# Windows:
.\.venv\Scripts\activate
# macOS/Linux:
# source .venv/bin/activate

pip install -r requirements.txt
```

### 2) Örnek (Sentetik) IoT verisi üret
Bu adım, hiç veri yokken de pipeline’ın çalıştığını göstermek için küçük bir CSV üretir:
```bash
python scripts/make_synthetic_iot_data.py
```

### 3) Temizle & Feature üret
```bash
python scripts/run_preprocess.py
```

### 4) Baseline model eğit (6 saat sonrası nem/sıcaklık tahmini)
```bash
python scripts/train_baseline.py
```

### 5) Dashboard’ı servis et (FastAPI)
Bu servis **HTML'i değiştirmeden** statik olarak sunar ve ayrıca örnek API endpoint’leri sağlar:
```bash
uvicorn dashboards.app:app --host 0.0.0.0 --port 8000
```

- Dashboard: http://localhost:8000  
- Health: http://localhost:8000/health  
- Latest sample data: http://localhost:8000/api/latest  
- Baseline predictions: http://localhost:8000/api/predict?hours_ahead=6

## AWS EC2 (Free Tier) Deploy (Özet)
1. EC2 Ubuntu instance aç (Security Group: inbound TCP `8000` veya reverse proxy ile `80`)
2. Instance’a bağlan:
```bash
ssh -i KEY.pem ubuntu@YOUR_EC2_PUBLIC_IP
```
3. Kurulum:
```bash
sudo apt update && sudo apt install -y python3-venv git
git clone YOUR_GITHUB_REPO_URL
cd iot-smart-agriculture
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python scripts/make_synthetic_iot_data.py
python scripts/run_preprocess.py
python scripts/train_baseline.py
nohup uvicorn dashboards.app:app --host 0.0.0.0 --port 8000 &
```
4. Tarayıcıdan: `http://YOUR_EC2_PUBLIC_IP:8000`

> Not: Üretimde systemd + reverse proxy (nginx) önerilir.

## Veri Notu
`scripts/make_synthetic_iot_data.py` küçük bir demo veri üretir. Projenizde isterseniz gerçek bir IoT datasetini `data/raw/` altına koyup `scripts/run_preprocess.py` ile aynı pipeline’ı kullanabilirsiniz.

## Lisans
Ders projesi için örnek repo şablonu.
