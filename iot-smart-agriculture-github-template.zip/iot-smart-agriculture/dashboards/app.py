from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Optional

import joblib
import numpy as np
import pandas as pd
from fastapi import FastAPI, Query
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

REPO_ROOT = Path(__file__).resolve().parents[1]
STATIC_DIR = Path(__file__).resolve().parent / "static"
DATA_PROCESSED = REPO_ROOT / "data" / "processed"
MODELS_DIR = REPO_ROOT / "models"

app = FastAPI(title="Smart Agriculture Dashboard API", version="1.0.0")

app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


@app.get("/", response_class=HTMLResponse)
def index() -> Any:
    # Serve the original dashboard HTML unchanged.
    return FileResponse(str(STATIC_DIR / "index.html"))


@app.get("/health")
def health() -> Dict[str, str]:
    return {"status": "ok"}


@app.get("/api/latest")
def latest() -> Dict[str, Any]:
    """Return latest processed sensor values if available, else fallback demo values."""
    p = DATA_PROCESSED / "latest.json"
    if p.exists():
        return json.loads(p.read_text(encoding="utf-8"))
    return {
        "timestamp": None,
        "zone": "demo",
        "soil_moisture_pct": 67,
        "temperature_c": 24,
        "humidity_pct": 58,
        "wind_kmh": 12,
        "light_lux": 850,
    }


def _load_model(kind: str):
    model_path = MODELS_DIR / f"{kind}_baseline.joblib"
    if not model_path.exists():
        return None
    return joblib.load(model_path)


@app.get("/api/predict")
def predict(hours_ahead: int = Query(6, ge=1, le=24)) -> Dict[str, Any]:
    """Baseline prediction endpoint (uses saved sklearn model if trained)."""
    df_path = DATA_PROCESSED / "features.parquet"
    if not df_path.exists():
        return {
            "error": "Processed features not found. Run: python scripts/run_preprocess.py",
            "hours_ahead": hours_ahead,
        }

    df = pd.read_parquet(df_path)
    df = df.sort_values("timestamp").reset_index(drop=True)

    # Use the latest row as current context; models are trained for fixed horizon=6h in this template.
    X_latest = df.drop(columns=["timestamp"]).tail(1)

    soil_model = _load_model("soil_moisture")
    temp_model = _load_model("temperature")

    out: Dict[str, Any] = {"hours_ahead": hours_ahead}

    if soil_model is None or temp_model is None:
        out["warning"] = "Models not found. Run: python scripts/train_baseline.py"
        out["soil_moisture_pred_pct"] = None
        out["temperature_pred_c"] = None
        return out

    out["soil_moisture_pred_pct"] = float(soil_model.predict(X_latest)[0])
    out["temperature_pred_c"] = float(temp_model.predict(X_latest)[0])
    return out
