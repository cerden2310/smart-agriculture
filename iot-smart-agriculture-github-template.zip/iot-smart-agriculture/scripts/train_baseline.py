from __future__ import annotations

from pathlib import Path

import joblib
import pandas as pd

from src.iot_dashboard.config import PATHS
from src.iot_dashboard.features import make_targets
from src.iot_dashboard.models import train_ridge_baseline

FEATURES_IN = PATHS.data_processed / "features.parquet"


def main() -> None:
    if not FEATURES_IN.exists():
        raise FileNotFoundError(f"Missing processed features: {FEATURES_IN}. Run: python scripts/run_preprocess.py")

    df = pd.read_parquet(FEATURES_IN)

    # Create targets at horizon=6 (6 hours if 1h cadence)
    df = df.assign(zone="zone")  # single-zone placeholder for targets function
    df = make_targets(df, horizon_steps=6)

    feature_cols = [c for c in df.columns if c not in {"timestamp", "zone", "soil_moisture_target", "temperature_target"}]

    soil_res = train_ridge_baseline(df, target_col="soil_moisture_target", feature_cols=feature_cols, alpha=1.0)
    temp_res = train_ridge_baseline(df, target_col="temperature_target", feature_cols=feature_cols, alpha=1.0)

    PATHS.models.mkdir(parents=True, exist_ok=True)
    joblib.dump(soil_res.model, PATHS.models / "soil_moisture_baseline.joblib")
    joblib.dump(temp_res.model, PATHS.models / "temperature_baseline.joblib")

    metrics = {
        "soil_moisture_mae": soil_res.mae,
        "temperature_mae": temp_res.mae,
        "horizon_hours": 6,
    }
    (PATHS.models / "metrics.json").write_text(
        __import__("json").dumps(metrics, indent=2),
        encoding="utf-8",
    )

    print("Saved models to models/")
    print(metrics)


if __name__ == "__main__":
    main()
