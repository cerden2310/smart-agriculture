from __future__ import annotations

import math
from datetime import datetime, timedelta, timezone
from pathlib import Path
import numpy as np
import pandas as pd

# Generates small demo dataset so the pipeline runs without external data.
# Output: data/raw/sensors.csv

REPO_ROOT = Path(__file__).resolve().parents[1]
OUT = REPO_ROOT / "data" / "raw" / "sensors.csv"

np.random.seed(42)

zones = ["zone_a", "zone_b", "zone_c", "zone_d", "zone_e"]
start = datetime.now(timezone.utc) - timedelta(days=7)

rows = []
for z in zones:
    soil = 65 + np.random.randn() * 2
    temp = 22 + np.random.randn() * 1.5
    hum = 55 + np.random.randn() * 3
    wind = 10 + np.random.randn() * 1.0
    light = 800 + np.random.randn() * 30

    for i in range(7 * 24):  # hourly for 7 days
        ts = start + timedelta(hours=i)

        # simple daily seasonality + noise
        daily = math.sin(2 * math.pi * (i % 24) / 24)
        soil = np.clip(soil - 0.05 + np.random.randn() * 0.2, 20, 95)
        temp = np.clip(22 + 4 * daily + np.random.randn() * 0.8, -10, 45)
        hum = np.clip(55 - 8 * daily + np.random.randn() * 2.0, 10, 95)
        wind = np.clip(10 + 2 * np.random.randn(), 0, 40)
        light = np.clip(200 + 900 * max(0, daily) + np.random.randn() * 50, 0, 20000)

        rows.append(
            {
                "timestamp": ts.isoformat(),
                "zone": z,
                "soil_moisture_pct": float(soil),
                "temperature_c": float(temp),
                "humidity_pct": float(hum),
                "wind_kmh": float(wind),
                "light_lux": float(light),
            }
        )

df = pd.DataFrame(rows)
OUT.parent.mkdir(parents=True, exist_ok=True)
df.to_csv(OUT, index=False)
print(f"Wrote {len(df):,} rows -> {OUT}")
