from __future__ import annotations

from pathlib import Path

import pandas as pd

from src.iot_dashboard.config import PATHS
from src.iot_dashboard.io import read_sensor_csv
from src.iot_dashboard.cleaning import basic_clean
from src.iot_dashboard.features import make_lag_features
from src.iot_dashboard.utils import write_json

RAW = PATHS.data_raw / "sensors.csv"
FEATURES_OUT = PATHS.data_processed / "features.parquet"
LATEST_OUT = PATHS.data_processed / "latest.json"


def main() -> None:
    if not RAW.exists():
        raise FileNotFoundError(f"Missing raw data: {RAW}. Run: python scripts/make_synthetic_iot_data.py")

    df = read_sensor_csv(RAW)
    df = basic_clean(df)

    # Save latest snapshot for API
    latest = df.sort_values("timestamp").tail(1).iloc[0].to_dict()
    latest["timestamp"] = str(latest["timestamp"])
    write_json(LATEST_OUT, latest)

    feat = make_lag_features(df, lags=[1, 2, 3, 6], freq_minutes=60)
    feat = feat.drop(columns=["zone"])  # keep simple for baseline
    feat.to_parquet(FEATURES_OUT, index=False)

    print(f"Saved features -> {FEATURES_OUT}")
    print(f"Saved latest -> {LATEST_OUT}")


if __name__ == "__main__":
    main()
