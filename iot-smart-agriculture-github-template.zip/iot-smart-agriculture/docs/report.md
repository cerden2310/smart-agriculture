# Proje Raporu (Report)

## Özet
Bu çalışma, akıllı tarım sahası için IoT sensör verilerinden (toprak nemi, sıcaklık, hava nemi, rüzgâr, ışık)
izleme ve kısa vadeli tahmin (6 saat) yapan uçtan uca bir pipeline sunar.

## Veri Kaynağı
- `data/raw/sensors.csv` (demo için sentetik / veya gerçek dataset)

## Veri Hazırlama
- Duplicate temizliği, makul sınır clip
- Grup bazlı forward/back fill
- Saatlik resampling & interpolasyon
- Lag feature’ları (1,2,3,6)

## Model
- Baseline: Ridge Regression
- Değerlendirme: TimeSeriesSplit CV, MAE

## Dashboard
- `dashboards/static/index.html` dosyası **değiştirilmeden** servis edilir.
- `dashboards/app.py` FastAPI ile yayınlanır.

## Deploy (AWS EC2)
README’deki adımlar izlenerek EC2 üzerinde çalıştırılır.

## Gelecek İşler
- Gerçek dataset entegrasyonu
- Model çeşitliliği (ARIMA/Prophet/LSTM)
- Dashboard → API entegrasyonu (HTML’e minimal fetch eklenerek)
