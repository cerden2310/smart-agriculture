# Proje Önerisi (Proposal)

## 1) Problem Statement (Template)
We want to **monitor and predict** key environmental variables (soil moisture, temperature, humidity, wind, light)
for **smart agriculture zones**, because it impacts **water usage, crop health, and operational cost**.
We will use data from **IoT sensors** at **hourly cadence** (or finer granularity).
Success looks like **reducing irrigation events by X%** while maintaining **soil moisture within [A,B]** and achieving **MAE ≤ Y** for 6-hour-ahead predictions.

## 2) In Scope
- Data ingestion (CSV; opsiyonel MQTT)
- Cleaning & imputation
- Baseline visualization / dashboard (mevcut HTML dashboard)
- Baseline modeling (6h ahead)
- AWS EC2 deployment

## 3) Out of Scope
- Real-time embedded deployment
- Custom hardware integration
- EC2 Free Tier ötesi ağır cloud infra

## 4) Dataset
- Demo: sentetik veri (repo içinde)
- Alternatif: kamuya açık IoT/time-series dataset (UCI/Kaggle vb.)

## 5) KPI / Başarı Kriteri
- Soil moisture 6h ahead MAE
- Temperature 6h ahead MAE
- Dashboard uptime & deploy doğrulaması
