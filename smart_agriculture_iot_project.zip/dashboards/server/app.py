from __future__ import annotations

import os
from flask import Flask, send_from_directory

# dashboards/server/app.py
# Serves the provided HTML unchanged.

HERE = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(os.path.dirname(HERE), "static")

app = Flask(__name__, static_folder=STATIC_DIR)

@app.get("/")
def index():
    return send_from_directory(STATIC_DIR, "smart_agriculture_dashboard_en.html")

@app.get("/health")
def health():
    return {"status": "ok"}

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8000, debug=False)
