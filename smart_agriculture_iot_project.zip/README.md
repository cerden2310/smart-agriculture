# Smart Agriculture Monitoring System (IoT + Applied Data Science)

This repository is an **end-to-end course project template** for an IoT data science workflow:
data ingestion → cleaning/prep → baseline modeling → dashboarding → deployment on **AWS EC2 (Free Tier)**.

> The provided dashboard HTML is included **unchanged** at:
> `dashboards/static/smart_agriculture_dashboard_en.html`

## Project Problem Statement (Template)
We want to **monitor and forecast** short-term soil moisture and temperature for a smart agriculture system, because it impacts irrigation decisions and resource usage.
We will use data from sensors (soil moisture, temperature, humidity, light, wind) at a chosen cadence (e.g., 1–5 minutes).
Success looks like maintaining soil moisture within an optimal range and achieving acceptable forecast error (e.g., MAE).

## Repository Structure
```
project-root/
  data/
    raw/          # raw CSVs (not committed)
    processed/    # cleaned feature tables (small samples OK)
  notebooks/      # EDA / cleaning / feature engineering experiments
  src/            # reusable modules (io, preprocessing, features, models)
  dashboards/
    static/       # unchanged HTML dashboard
    server/       # Flask static server (+ optional API)
  models/         # saved artifacts (.joblib)
  docs/           # proposal, report, deployment notes
  README.md
```

## Quick Start (Local)

### 1) Create a virtual environment
```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
```

### 2) Generate sample sensor data
```bash
python -m src.simulate_data --out data/raw/sensor_data.csv --days 3 --freq-min 5
```

### 3) Clean + build features
```bash
python -m src.prepare_dataset --in data/raw/sensor_data.csv --out data/processed/features.csv
```

### 4) Train a baseline model
```bash
python -m src.train_model --in data/processed/features.csv --model-out models/moisture_model.joblib
```

### 5) Run the dashboard (static HTML)
```bash
python -m dashboards.server.app
# then open http://127.0.0.1:8000
```

### 6) Run the prediction API (optional)
```bash
uvicorn src.api:app --host 0.0.0.0 --port 9000
# Example request (adapt values as needed):
# curl -X POST http://127.0.0.1:9000/predict/moisture \
#   -H "Content-Type: application/json" \
#   -d '{"temp_c":24,"humidity":58,"light_lux":850,"wind_kmh":12,"hour":14,"dayofweek":3,"temp_roll_mean_1h":24,"moisture_roll_mean_1h":67}'
```

## Deployment (AWS EC2 Free Tier)
See: `docs/aws_ec2_deployment.md`

## Documentation / Report
- `docs/proposal.md` – proposal template
- `docs/report.md` – report template (method, results, limitations)

## Notes
- The **HTML dashboard is used as-is** (texts/images unchanged).
- Replace the simulated data pipeline with real sensor ingestion (MQTT/CSV) when available.
