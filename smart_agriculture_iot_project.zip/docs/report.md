# Project Report (Template)

## Abstract
(1–2 paragraphs)

## Problem
Use the course problem statement template.

## Data
- Source
- Sampling cadence
- Features available
- Missing data patterns

## Data Preparation
- Cleaning steps
- Imputation
- Normalization (if used)

## Exploratory Analysis
- Key plots (add figures under `docs/figures/`)

## Baseline Model
- Model choice and justification
- Train/test split approach
- Metrics (MAE, RMSE, etc.)
- Results and discussion

## Dashboard
- How it is served
- What it shows

## Deployment
- EC2 setup notes
- How to run the app and/or API

## Limitations & Next Steps
- Real-time ingestion via MQTT
- Anomaly detection + alerts
- Stronger time-series forecasting models
