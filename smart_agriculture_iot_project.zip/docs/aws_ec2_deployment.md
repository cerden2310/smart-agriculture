# AWS EC2 Deployment (Free Tier)

This guide deploys:
- Flask static server for the dashboard (port 8000)
- Optional FastAPI prediction service (port 9000)

## 1) Launch EC2
- Ubuntu 22.04 LTS (Free Tier eligible)
- Open inbound ports:
  - 22 (SSH)
  - 8000 (Dashboard)
  - 9000 (API, optional)

## 2) SSH into EC2
```bash
ssh -i your-key.pem ubuntu@<EC2_PUBLIC_IP>
```

## 3) Install dependencies
```bash
sudo apt update
sudo apt install -y python3-pip python3-venv git
```

## 4) Clone repository
```bash
git clone <YOUR_REPO_URL>
cd <YOUR_REPO_DIR>
```

## 5) Create venv + install
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## 6) (Optional) Generate data + train model
```bash
python -m src.simulate_data --out data/raw/sensor_data.csv --days 3 --freq-min 5
python -m src.prepare_dataset --in data/raw/sensor_data.csv --out data/processed/features.csv
python -m src.train_model --in data/processed/features.csv --model-out models/moisture_model.joblib
```

## 7) Run dashboard server
```bash
python -m dashboards.server.app
# visit: http://<EC2_PUBLIC_IP>:8000
```

## 8) Run API (optional)
```bash
uvicorn src.api:app --host 0.0.0.0 --port 9000
# visit: http://<EC2_PUBLIC_IP>:9000/docs
```

## Production note (optional)
For a production-style setup you can add Nginx + systemd services, but the above is enough for the course scope.
