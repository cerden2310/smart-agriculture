from __future__ import annotations

import argparse
import os
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

import numpy as np
import pandas as pd

@dataclass
class SimConfig:
    days: int = 7
    freq_min: int = 5
    seed: int = 42

def _daily_cycle(hour: np.ndarray) -> np.ndarray:
    return np.sin(2 * np.pi * hour / 24.0)

def simulate(config: SimConfig) -> pd.DataFrame:
    rng = np.random.default_rng(config.seed)

    start = datetime.now(timezone.utc).replace(second=0, microsecond=0) - timedelta(days=config.days)
    periods = int((config.days * 24 * 60) / config.freq_min)
    ts = pd.date_range(start=start, periods=periods, freq=f"{config.freq_min}min", tz="UTC")

    hour = (ts.hour + ts.minute / 60.0).to_numpy()

    temp = 22 + 6 * _daily_cycle(hour - 14) + rng.normal(0, 0.8, size=periods)
    humidity = 60 - 8 * _daily_cycle(hour - 14) + rng.normal(0, 2.0, size=periods)
    humidity = np.clip(humidity, 20, 95)

    daylight = np.clip(_daily_cycle(hour - 6), 0, None)
    light = 200 + 900 * daylight + rng.normal(0, 30, size=periods)
    light = np.clip(light, 0, None)

    wind = 8 + 4 * rng.normal(0, 1.0, size=periods)
    wind = np.clip(wind, 0, 40)

    moisture = np.zeros(periods)
    moisture[0] = 70
    for i in range(1, periods):
        evap = 0.04 + 0.004 * max(temp[i] - 20, 0) + 0.001 * wind[i]
        moisture[i] = moisture[i - 1] - evap + rng.normal(0, 0.1)
        if rng.random() < 0.01:
            moisture[i] += rng.uniform(6, 14)
        moisture[i] = np.clip(moisture[i], 25, 90)

    df = pd.DataFrame(
        {
            "timestamp_utc": ts.astype(str),
            "temp_c": temp.round(2),
            "humidity_pct": humidity.round(2),
            "light_lux": light.round(1),
            "wind_kmh": wind.round(2),
            "soil_moisture_pct": moisture.round(2),
        }
    )
    return df

def main() -> None:
    p = argparse.ArgumentParser(description="Generate simulated IoT sensor data as CSV.")
    p.add_argument("--out", required=True, help="Output CSV path (e.g., data/raw/sensor_data.csv)")
    p.add_argument("--days", type=int, default=7, help="Number of days to simulate")
    p.add_argument("--freq-min", type=int, default=5, help="Sampling frequency in minutes")
    p.add_argument("--seed", type=int, default=42)
    args = p.parse_args()

    df = simulate(SimConfig(days=args.days, freq_min=args.freq_min, seed=args.seed))
    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    df.to_csv(args.out, index=False)
    print(f"Wrote {len(df):,} rows -> {args.out}")

if __name__ == "__main__":
    main()
