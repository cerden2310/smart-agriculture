from __future__ import annotations

import argparse
import os
import pandas as pd

def load_csv(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    df["timestamp_utc"] = pd.to_datetime(df["timestamp_utc"], utc=True, errors="coerce")
    df = df.dropna(subset=["timestamp_utc"]).sort_values("timestamp_utc")
    return df

def clean_and_feature_engineer(df: pd.DataFrame) -> pd.DataFrame:
    numeric_cols = ["temp_c", "humidity_pct", "light_lux", "wind_kmh", "soil_moisture_pct"]
    for c in numeric_cols:
        df[c] = pd.to_numeric(df[c], errors="coerce")

    # Simple missing-value strategy
    df[numeric_cols] = df[numeric_cols].ffill().bfill()

    # Time features
    df["hour"] = df["timestamp_utc"].dt.hour
    df["dayofweek"] = df["timestamp_utc"].dt.dayofweek

    # Rolling features (assumes 5-min cadence; adjust window if cadence changes)
    df["temp_roll_mean_1h"] = df["temp_c"].rolling(window=12, min_periods=1).mean()
    df["moisture_roll_mean_1h"] = df["soil_moisture_pct"].rolling(window=12, min_periods=1).mean()

    # Forecast target: next-step soil moisture
    df["target_moisture_next"] = df["soil_moisture_pct"].shift(-1)
    df = df.dropna(subset=["target_moisture_next"])
    return df

def main() -> None:
    p = argparse.ArgumentParser(description="Prepare a processed dataset (cleaning + features).")
    p.add_argument("--in", dest="inp", required=True, help="Input raw CSV path")
    p.add_argument("--out", required=True, help="Output processed CSV path")
    args = p.parse_args()

    df = load_csv(args.inp)
    df = clean_and_feature_engineer(df)

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    df.to_csv(args.out, index=False)
    print(f"Wrote {len(df):,} rows -> {args.out}")

if __name__ == "__main__":
    main()
