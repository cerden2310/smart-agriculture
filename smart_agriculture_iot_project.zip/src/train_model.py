from __future__ import annotations

import argparse
import os
import joblib
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error
from sklearn.model_selection import train_test_split

FEATURES = [
    "temp_c",
    "humidity_pct",
    "light_lux",
    "wind_kmh",
    "hour",
    "dayofweek",
    "temp_roll_mean_1h",
    "moisture_roll_mean_1h",
]

TARGET = "target_moisture_next"

def main() -> None:
    p = argparse.ArgumentParser(description="Train a baseline model for next-step soil moisture forecast.")
    p.add_argument("--in", dest="inp", required=True, help="Input processed features CSV path")
    p.add_argument("--model-out", required=True, help="Output model path (joblib)")
    args = p.parse_args()

    df = pd.read_csv(args.inp)
    X = df[FEATURES]
    y = df[TARGET]

    # Time-series friendly split (no shuffle)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, shuffle=False
    )

    model = RandomForestRegressor(
        n_estimators=200,
        random_state=42,
        n_jobs=-1,
        max_depth=12,
    )
    model.fit(X_train, y_train)

    preds = model.predict(X_test)
    mae = mean_absolute_error(y_test, preds)
    print(f"Test MAE: {mae:.3f} moisture-%")

    os.makedirs(os.path.dirname(args.model_out), exist_ok=True)
    joblib.dump({"model": model, "features": FEATURES}, args.model_out)
    print(f"Saved model -> {args.model_out}")

if __name__ == "__main__":
    main()
