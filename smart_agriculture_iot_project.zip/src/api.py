from __future__ import annotations

import os
import joblib
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

MODEL_PATH = os.getenv("MOISTURE_MODEL_PATH", "models/moisture_model.joblib")

class MoistureFeatures(BaseModel):
    temp_c: float = Field(..., description="Air temperature in °C")
    humidity: float = Field(..., description="Air humidity in %")
    light_lux: float = Field(..., description="Light intensity in lux")
    wind_kmh: float = Field(..., description="Wind speed in km/h")
    hour: int = Field(..., ge=0, le=23)
    dayofweek: int = Field(..., ge=0, le=6)
    temp_roll_mean_1h: float = Field(..., description="Rolling mean temp (1h)")
    moisture_roll_mean_1h: float = Field(..., description="Rolling mean soil moisture (1h)")

app = FastAPI(title="Smart Agriculture Prediction API", version="1.0.0")

def _load():
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(
            f"Model not found at '{MODEL_PATH}'. Train it first: python -m src.train_model ..."
        )
    obj = joblib.load(MODEL_PATH)
    return obj["model"], obj["features"]

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/predict/moisture")
def predict_moisture(payload: MoistureFeatures):
    try:
        model, feature_names = _load()
    except FileNotFoundError as e:
        raise HTTPException(status_code=500, detail=str(e))

    row = {
        "temp_c": payload.temp_c,
        "humidity_pct": payload.humidity,
        "light_lux": payload.light_lux,
        "wind_kmh": payload.wind_kmh,
        "hour": payload.hour,
        "dayofweek": payload.dayofweek,
        "temp_roll_mean_1h": payload.temp_roll_mean_1h,
        "moisture_roll_mean_1h": payload.moisture_roll_mean_1h,
    }

    X = [[row[name] for name in feature_names]]
    pred = float(model.predict(X)[0])
    return {"predicted_moisture_next": pred}
